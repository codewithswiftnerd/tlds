var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_lib.js
var lib_exports = {};
function init() {
  const admin = require("firebase-admin");
  if (!admin.apps.length) {
    admin.initializeApp({ credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
  }
  return admin;
}
async function authUid(event) {
  const h = event.headers.authorization || event.headers.Authorization || "";
  const m = h.match(/^Bearer (.+)$/);
  if (!m) throw new HttpError(401, "functions/unauthenticated", "Sign-in required.");
  try {
    return (await init().auth().verifyIdToken(m[1])).uid;
  } catch {
    throw new HttpError(401, "functions/unauthenticated", "Please sign in again.");
  }
}
async function loadMeeting(id) {
  if (typeof id !== "string" || !id) throw new HttpError(400, "functions/invalid-argument", "meetingId is required.");
  const snap = await init().firestore().collection("meetings").doc(id).get();
  if (!snap.exists) throw new HttpError(404, "functions/not-found", "Meeting not found.");
  return snap.data();
}
var HttpError, roomService, reply, route;
var init_lib = __esm({
  "netlify/functions/_lib.js"() {
    HttpError = class extends Error {
      constructor(status, code, message) {
        super(message);
        this.status = status;
        this.code = code;
      }
    };
    roomService = () => {
      const { RoomServiceClient } = require("livekit-server-sdk");
      return new RoomServiceClient(process.env.LIVEKIT_URL.replace(/^wss:/, "https:").replace(/^ws:/, "http:"), process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET);
    };
    reply = (status, body) => ({ statusCode: status, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    route = (fn) => async (event) => {
      if (event.httpMethod !== "POST") return reply(405, { error: "POST only." });
      try {
        const uid = await authUid(event);
        const body = event.body ? JSON.parse(event.body) : {};
        return reply(200, await fn({ uid, body }));
      } catch (e) {
        if (e instanceof HttpError) return reply(e.status, { error: e.message, code: e.code });
        console.error(e);
        return reply(500, { error: `Call service error: ${String(e.message || e).slice(0, 160)}`, code: "functions/internal" });
      }
    };
    module.exports = { init, HttpError, loadMeeting, roomService, route };
  }
});

// netlify/functions/getRoomToken.js
var { init: init2, HttpError: HttpError2, loadMeeting: loadMeeting2, roomService: roomService2, route: route2 } = (init_lib(), __toCommonJS(lib_exports));
exports.handler = route2(async ({ uid, body }) => {
  const meeting = await loadMeeting2(body.meetingId);
  const userSnap = await init2().firestore().collection("users").doc(uid).get();
  const project = init2().app().options.credential?.projectId || process.env.GCLOUD_PROJECT || "unknown";
  if (!userSnap.exists) {
    console.error("No users/%s document in project %s", uid, project);
    throw new HttpError2(403, "functions/permission-denied", `Could not find your member profile (call service is reading project "${project}"). Check FIREBASE_SERVICE_ACCOUNT belongs to the same Firebase project as the app.`);
  }
  if (userSnap.data().disabled === true) throw new HttpError2(403, "functions/permission-denied", "Your account has been deactivated by an administrator.");
  if (meeting.status !== "live") throw new HttpError2(412, "functions/failed-precondition", "This meeting is not live.");
  if ((meeting.removedUids || []).includes(uid)) throw new HttpError2(403, "functions/permission-denied", "You were removed from this meeting.");
  const max = parseInt(process.env.MAX_PARTICIPANTS || "150", 10);
  try {
    const people = await roomService2().listParticipants(body.meetingId);
    if (people.length >= max && !people.some((p) => p.identity === uid)) throw new HttpError2(429, "functions/resource-exhausted", "This meeting is full.");
  } catch (e) {
    if (e instanceof HttpError2) throw e;
  }
  const { AccessToken } = require("livekit-server-sdk");
  const at = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, { identity: uid, name: userSnap.data().name || "Member", ttl: "6h" });
  at.addGrant({ roomJoin: true, room: body.meetingId, canPublish: true, canSubscribe: true, canPublishData: false });
  return { token: await at.toJwt(), url: process.env.LIVEKIT_URL };
});
